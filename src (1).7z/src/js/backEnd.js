var dataJson = [
  {
    'id': 1,
    'category': 'cap',
    'size': ['XL', 'S'],
    'color': ['red'],
    'price': '25.0',
    'description': 'cap',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 2,
    'category': 'T-shirt',
    'size': ['L', 'S'],
    'color': ['red'],
    'price': '25.0',
    'description': 'T-shirt',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 3,
    'category': 'T-shirt',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '25.0',
    'description': 'T-shirt',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 4,
    'category': 'cap',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '25.8',
    'description': 'cap',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 5,
    'category': 'sweater',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '25.0',
    'description': 'sweater',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 6,
    'category': 'T-shirt',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '28.0',
    'description': 'T-shirt',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 7,
    'category': 'cap',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '20.0',
    'description': 'cap',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 8,
    'category': 'cap',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '58.0',
    'description': 'cap ',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 9,
    'category': 'cap',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '1.0',
    'description': 'cap',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  },
  {
    'id': 10,
    'category': 'cap',
    'size': ['M', 'XL'],
    'color': ['blue'],
    'price': '1.0',
    'description': 'cap',
    'img': ['https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173487_1_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173489_3_v1.jpg',
      'https://a.lmcdn.ru/pi/img46x66/N/I/NI001CMWJW39_5173488_2_v1.jpg']
  }

]

// var categories = ['cap', 'T-shirt', 'sweater']
// var sizes = ['S', 'M', 'L', 'XL']
// var colors = ['red', 'blue', 'black', 'green']

export default {
  dataJson
}
