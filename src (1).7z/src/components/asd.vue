<template>
<div>
<div class="leftContainer col-md-6">
    <h3>Checkout</h3>
    <bag-components  @dataRemove="getNewData" @changeCount="recountCostByCount"
     v-for="item in asd" :product="item"></bag-components>
</div>
<div class="rightContainer col-md-6">
  <div class="vaucherSection">
    <p>Vaucher Code</p>
    <input v-model="vaucherCode" type="text">
    <button v-on:click="recountCostByVaucher">Submit</button>
  </div>
  <hr></hr>
  <div class="priceProcessionSection">
    <div>
      <span>Bascet</span>
      <span class="coast">{{bagCost}}</span>
    </div>
    <div>
      <span>Vaucher Reduction</span>
      <span class="coast">{{vaucherReduction}}</span>
    </div>
    <div>
      <span>Shiping</span>
      <span class="coast">{{shiping}}</span>
    </div>
    <div class="total">
    <span>Grand total</span>
    <span class="coast">{{total}}</span>
    </div>
  </div>
  <div class="paymentSectio">

  </div>
  <div class="userInfoSection">
    <p>Your detalis</p>
    <div>
      <input  placeholder='First Name' v-model="firstName" type="text">
      <span class="errorMsg">{{errorMsg}}</span>
    </div>
    <div>
      <input placeholder="Last Name"v-model="lastName" type="text">
      <span class="errorMsg">{{errorMsg}}</span>
    </div>
    <div>
      <input placeholder="Email"v-model="email" type="text">
      <span class="errorMsg">{{errorMsg}}</span>
    </div>
    <div>
      <input placeholder="Phone"v-model="phone" type="text">
    </div>
    <div>
      <input placeholder="Addres"v-model="adrees" type="text">
    </div>
    <button v-on:click="completePurchase">Complete Purchase</button>
  </div>
  <hr></hr>
</div>
</div>
</template>



<script>
import BagComponents from '@/components/bagComponents'
// import mainBackEnd from '../js/backEnd'

export default {
  name: 'product_list',
  data () {
    return {
      bagData: '',
      vaucherCode: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      adrees: '',
      bagCost: 0,
      shiping: 9.90,
      total: 0,
      errorMsg: '',
      vaucherReduction: 0,
      productKey: '',
      prorocentDiscount: {
        'disck10': 0.10
      },
      staticDiscount: {
        'disck5eur': 5
      }

    }
  },
  components: {
    BagComponents
  },
  created () {
    this.bagData = JSON.parse(localStorage['bag'])
    for (var key in this.bagData) {
      // console.log(key)
      this.bagCost += this.bagData[key].count * this.bagData[key].price
    }
    this.bagCost = Number(this.bagCost)
    var total = this.bagCost - this.vaucherReduction + this.shiping
    this.total = total.toFixed(2)
    // this.shiping = Number(this.shiping)
    // this.vaucherReduction = Number(this.vaucherReduction)
    // console.log(this.bagCost)
  },
  methods: {
    getNewData: function (id) {
      // console.log(this.bagData)
      // delete this.bagData[id]
      // console.log(this.bagData)
      this.procentKey = id
      // this.bagData = JSON.parse(localStorage['bag'])
      this.bagCost = 0
      for (var key in this.bagData) {
      // console.log(key)
        var bagCost = this.bagData[key].count * this.bagData[key].price
        this.bagCost += bagCost
      }
      var total = this.bagCost - this.vaucherReduction + this.shiping
      this.total = total.toFixed(2)
    },
    recountCostByCount: function () {
      this.bagData = JSON.parse(localStorage['bag'])
      this.bagCost = 0
      for (var key in this.bagData) {
      // console.log(key)
        var bagCost = this.bagData[key].count * this.bagData[key].price
        this.bagCost += bagCost
      }
      var total = this.bagCost - this.vaucherReduction + this.shiping
      this.total = total.toFixed(2)
      // this.bagCost += this.bagData[key].count * this.bagData[key].price
      // if (znak === '+') {
      //   this.bagCost += price
      // } else {
      //   this.bagCost -= price
      // }

      console.log(this.bagCost)
      // console.log(count)
      // var y = count
      // var c = 0
      // for (var key in this.bagData) {
      //   var x = this.bagData[key].price
      //   console.log(this.bagData[key])
      //   c = x * y
      //   console.log(c)
      // }
      // this.bagCost = x
    },
    recountCostByVaucher: function () {
      // console.log(1 * '10%')
      for (var procentKey in this.prorocentDiscount) {
        if (procentKey === this.vaucherCode) {
          var discount = this.bagCost * this.prorocentDiscount[procentKey]
          this.vaucherReduction = discount
          // console.log(this.prorocentDiscount[procentKey])
          // var x = this.bagCost * ke
          // return
        }
      }
      for (var staticKey in this.staticDiscount) {
        if (staticKey === this.vaucherCode) {
          discount = this.staticDiscount[staticKey]
          this.vaucherReduction = discount
          // this.bagCost -= this.vaucherReduction
          // console.log(this.prorocentDiscount[key])
          // var x = this.bagCost * ke
        }
      }
      var total = this.bagCost - this.vaucherReduction + this.shiping
      this.total = total.toFixed(2)
      this.vaucherCode = ''
      // console.log(this.vaucherReduction)
    },
    completePurchase: function () {
      if (this.firstName === '' || this.lastName === '' || this.email === '') {
        this.errorMsg = 'Fill field'
      } else {
        this.errorMsg = ''
      }
    },
    computed: {
      asd: function () {
        console.log(this.bagData)
        if (this.procentKey === '') {
          return this.bagData
        } else {
          delete this.bagData[this.procentKey]
          return this.bagData
        }
      }
    }
  }
  // computed: {
  //   f: function () {
  //     return this.bagData
  //   }
  // }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
} */

.leftContainer{
  padding-left: 50px;
  width: 50%;
}
.rightContainer{
  width: 20%;
}
.rightContainer input{
  width: 100%
}
.coast{
  float: right;
}
/* .vaucherSection input{
  display: block;
} */
.errorMsg{
  color: red;
}

.total{
  padding-top: 30px;
  font-size: 20px; 
}
/* .userInfoSection input {
  display: inline-block;
} */
</style>

