<template>
  <div class="product_section">
    <!-- <div class="col-md-4 product">
        <router-link :to="/productInfo/+product.id">
        <a class="thumbnail">
            <img :src="product.img[0]" alt="">
            <p class="title">{{product.description}} - <span class="price">{{product.price}}</span></p>
        </a>
        </router-link> -->
        <div>
            <hr></hr>
            <div class="leftBlock">
                <div class="title">
                    <h2></h2>
                    <button v-on:click="removeProduct">X</button>
                </div>
                <div class="size">Size {{product.size}}</div>
                <div class="price"> {{ product.price }} EUR </div>
                <div class="color">Color {{product.color[0]}}</div>
                <div>
                    <button v-on:click="minus" class="minus">-</button>
                    <span class="count">{{count}}</span>
                    <button v-on:click="plus" class="plus">+</button>
                </div>
            </div>
            <div class="rightBlock">

                <img :src="product.img[0]" alt="">
            </div>
        </div>
	</div>
</template>


<script>

export default {
  name: 'bag_list',
  data () {
    return {
    //   bagData: '',
      count: 0
    }
  },
  methods: {
    plus: function () {
      this.count++
      var bag = JSON.parse(localStorage['bag'])
      bag[this.product.id].count = this.count
      localStorage['bag'] = JSON.stringify(bag)
    //   var changeCostOn = this.count * this.product.price
      this.$emit('changeCount', this.product.id, this.count)
    },
    minus: function () {
      this.count--
      var bag = JSON.parse(localStorage['bag'])
      bag[this.product.id].count = this.count
      localStorage['bag'] = JSON.stringify(bag)
    //   var changeCostOn = this.count * this.product.price
      this.$emit('changeCount', this.product.id, this.count)
    },
    removeProduct: function () {
      var bag = JSON.parse(localStorage['bag'])
      delete bag[this.product.id]
      localStorage['bag'] = JSON.stringify(bag)
      this.$emit('dataRemove', this.product.id)
    }
  },
  props: ['product'],
  created () {
    this.count = this.product.count
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1,
h2 {
    font-weight: normal;
}

ul {
    list-style-type: none;
    padding: 0;
}

li {
    display: inline-block;
    margin: 0 10px;
}

a {
    color: #42b983;
}
.price{
    font-weight: bold
}
.leftBlock{
    display: inline-block;
}
.rightBlock{
    float: right;
    height: 150px;
    width: 200px;
}
.rightBlock img{
    height: 100%;
}
</style>
