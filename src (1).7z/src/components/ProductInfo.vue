<template>
<div class="app">
  <div class="leftContainer col-md-4">
    <ad1 :imgs="dataInfo.img"></ad1>
  </div>
  <div id="rightContainer col-md-4">
    <select v-on:click="sortBy" id="size" v-model="size">
      <option value="">Sizes</option>
      <option v-for="size in sizes" 
      :value="size">{{size}}</option>
    </select>
    <span>{{errorMsg}}</span>
    <button v-if="buttonMsg==='Add to bag'"v-on:click="addToBag">{{buttonMsg}}</button>
    <router-link v-else to='/bag'>
      <button >{{buttonMsg}}</button>
    </router-link>
  </div>
    <!-- <router-view class="view">
      {{$route.params.id}}
    </router-view> -->
</div>
</template>

<script>
// import Vue from 'vue'
// import Router from 'vue-router'
// Vue.use(Router)
import ad1 from '@/components/ad1'
import myBackend from '../js/backEnd'
// console.log(myBackend.dataJson[1].size)
// console.dir(router)
export default {
  name: 'app',
  data () {
    return {
      errorMsg: '',
      size: '',
      color: '',
      sort: '',
      produtKey: '',
      dataInfo: '',
      sizes: '',
      buttonMsg: 'Add to bag',
      options: {
        sizes: [

        ]
      }
    }
  },
  components: {
    ad1
  },
  methods: {
    sortBy: function () {
      // console.log(this.$route.params.id)
      // this.$router.to('Bag')
    },
    goToBag: function () {
      // this.$router.replace('Bag')
    },
    addToBag: function () {
      if (this.size === '') {
        this.errorMsg = 'Select size'
      } else {
        if (localStorage['bag'] === undefined) {
          var bag = {}
        // console.log()
        } else {
          bag = JSON.parse(localStorage['bag'])
        }
        // var product = {}
        this.dataInfo['size'] = this.size
        bag[this.produtKey] = this.dataInfo
        bag[this.produtKey].count = 1
        // delete bag[this.produtKey].img
        localStorage['bag'] = JSON.stringify(bag)
        this.buttonMsg = 'Processed to checkout'
        this.errorMsg = ''
      }
    }
    // getProductId: function (key) {
    //   // var s = window.location.href
    //   // s = s.match(new RegExp(key + '=([^&=]+)'))
    //   // return s ? s[1] : false
    // }
  },
  beforeMount () {
    this.produtKey = this.$route.params.id
    this.dataInfo = myBackend.dataJson[this.$route.params.id - 1]
    this.sizes = myBackend.dataJson[this.$route.params.id].size
  }
  // component: mc
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
} */

</style>
